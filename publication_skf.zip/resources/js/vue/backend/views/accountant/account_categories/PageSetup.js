export default {
    layout_title: 'Account Category Management',
    route_prefix: 'AcountantAccountCategories',
    store_prefix: 'accountant_category',
    pagination_limits: [10,5,25,50,100],
}
