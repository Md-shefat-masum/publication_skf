export default {
    layout_title: 'Account Entries Management',
    route_prefix: 'AcountantEntries',
    store_prefix: 'accountant_entry',
    pagination_limits: [10,5,25,50,100],
}
