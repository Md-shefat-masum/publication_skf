export default {
    layout_title: 'Payment Request Management',
    route_prefix: 'AdminPaymentRequest',
    store_prefix: 'admin_payment_request',
    pagination_limits: [10,5,25,50,100],
}
