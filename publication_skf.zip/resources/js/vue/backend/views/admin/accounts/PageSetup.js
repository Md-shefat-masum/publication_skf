export default {
    layout_title: 'Account Management',
    route_prefix: 'ProductionAccount',
    store_prefix: 'production_product',
    pagination_limits: [10,5,25,50,100],
}
