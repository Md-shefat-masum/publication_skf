export default {
    route_prefix: 'AdminTranslator',
    store_prefix: 'admin_translator',
    layout_title: 'Translator Management',
}
