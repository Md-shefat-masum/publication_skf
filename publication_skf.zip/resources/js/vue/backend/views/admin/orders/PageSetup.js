export default {
    layout_title: 'Order Management',
    route_prefix: 'AdminOrder',
    store_prefix: 'admin_order',
    pagination_limits: [10,5,25,50,100],
}
