export default {
    route_prefix: 'AdminProductCategory',
    store_prefix: 'category',
    layout_title: 'Category Management',
}
