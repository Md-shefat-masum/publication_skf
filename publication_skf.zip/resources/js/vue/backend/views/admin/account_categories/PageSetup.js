export default {
    layout_title: 'Account Category Management',
    route_prefix: 'ProductionAccountCategory',
    store_prefix: 'production_product',
    pagination_limits: [10,5,25,50,100],
}
