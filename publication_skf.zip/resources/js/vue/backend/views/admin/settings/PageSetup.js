export default {
    route_prefix: 'AdminSetting',
    store_prefix: 'admin_setting',
    layout_title: 'App Settings',
}
