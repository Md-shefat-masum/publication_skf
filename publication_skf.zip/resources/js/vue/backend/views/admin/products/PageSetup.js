export default {
    layout_title: 'Product Management',
    route_prefix: 'AdminProduct',
    store_prefix: 'admin_product',
    pagination_limits: [10,5,25,50,100],
}
